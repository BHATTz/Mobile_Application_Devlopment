package com.example.experiment21

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var main = findViewById<ConstraintLayout>(R.id.main)
        val colors = arrayListOf(
            Color.BLUE,
            Color.RED,
            Color.GREEN,
            Color.YELLOW,
            Color.MAGENTA
        )
        var randomColor= colors.random()
        main.setBackgroundColor(randomColor)

        var colorText = findViewById<TextView>(R.id.colorText)

        when (randomColor) {
            Color.BLUE -> colorText.text = "Current color is BLUE"
            Color.RED -> colorText.text = "Current color is RED"
            Color.GREEN -> colorText.text = "Current color is GREEN"
            Color.YELLOW -> colorText.text = "Current color is YELLOW"
            Color.MAGENTA -> colorText.text = "Current color is MAGENTA"
        }

    }
}