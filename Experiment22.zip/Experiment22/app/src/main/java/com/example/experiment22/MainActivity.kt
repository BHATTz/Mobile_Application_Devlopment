package com.example.experiment22

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Switch
import android.widget.TextView
import kotlin.math.ceil

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var amountEntered = findViewById<EditText>(R.id.amountEntered)
        val calculate = findViewById<Button>(R.id.calculate)
        val roundedSwitch = findViewById<Switch>(R.id.roundedSwitch)
        var outputBox = findViewById<TextView>(R.id.outputBox)
        var radioGroup = findViewById<RadioGroup>(R.id.radioGroup)

        calculate.setOnClickListener {
            val amountText = amountEntered.text.toString()
            if (amountText.isEmpty()) {
                outputBox.text = "Enter Valid amount!!"
                return@setOnClickListener
            }
            var amount = amountText.toInt()
            val tip = when (radioGroup.checkedRadioButtonId){
                R.id.r20 -> 0.20
                R.id.r18 -> 0.18
                R.id.r10 -> 0.10
                else -> 0.0
            }
            val tipAmount = amount * tip
            var totalAmount = amount + tipAmount
            if(roundedSwitch.isChecked){
                totalAmount = ceil(totalAmount)
                outputBox.text = "Rs. $totalAmount"
                return@setOnClickListener
            } else {
                outputBox.text = "Rs. $totalAmount"
                return@setOnClickListener
            }



        }

    }
}
