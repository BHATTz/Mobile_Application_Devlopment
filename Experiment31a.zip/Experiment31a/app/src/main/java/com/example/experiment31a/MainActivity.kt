package com.example.experiment31a

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var ph = findViewById<EditText>(R.id.ph)
        var msg = findViewById<EditText>(R.id.msg)
        val send = findViewById<Button>(R.id.send)

        send.setOnClickListener{
            var phone = ph.text.toString()
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$phone"))
            intent.putExtra("sms_body",msg.text.toString())

            startActivity(intent)
        }
    }
}