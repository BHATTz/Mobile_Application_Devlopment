package com.example.experiment32b

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley

class MainActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var weatherTextView = findViewById<TextView>(R.id.weatherTextView)
            var url = "http://api.weatherstack.com/current?access_key=fa77aab10fae4b20162c37acca8126e0&query=Kharar"
            val request = JsonObjectRequest(Request.Method.GET, url, null,
                { response ->
                    val location = response.getJSONObject("location")
                    val observation = response.getJSONObject("current")

                    val description = observation.getJSONArray("weather_descriptions").getString(0)
                    val temperature = observation.getDouble("temperature")
                    val city = location.getString("name")
                    val country = location.getString("country")

                    weatherTextView.text = "Weather in $city, $country: $description, Temperature: $temperature °C"
                },
                { error ->
                    weatherTextView.text = "Error getting weather data: ${error.message}"
                })

            Volley.newRequestQueue(this).add(request)
    }
}
