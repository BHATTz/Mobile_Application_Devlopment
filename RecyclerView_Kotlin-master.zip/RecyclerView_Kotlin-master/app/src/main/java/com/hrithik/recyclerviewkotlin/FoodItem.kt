package com.hrithik.recyclerviewkotlin

data class FoodItem(val name:String, val price:Float)
