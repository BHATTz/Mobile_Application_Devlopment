# WeatherApp
Get your locality current weather report in just at your finger tip.
## Scan To download my weather App ~> <a href="https://imgbb.com/"><img src="https://i.ibb.co/T86QhzF/chart.png" alt="chart" border="0"></a>
<a href="https://ibb.co/b1f1rLh"><img src="https://i.ibb.co/CBrBnvd/1.jpg" alt="1" border="0"></a>
<a href="https://ibb.co/q7H2swL"><img src="https://i.ibb.co/HBc9zQL/2.jpg" alt="2" border="0"></a>
<a href="https://ibb.co/pR916Q3"><img src="https://i.ibb.co/ZYkfRSh/3.jpg" alt="3" border="0"></a>
