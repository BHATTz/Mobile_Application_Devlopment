package com.example.exp7

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class DisplayEntriesActivity : AppCompatActivity() {
    private lateinit var usernameText: TextView
    private lateinit var passwordText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_display_entries)

        usernameText = findViewById(R.id.username_text)
        passwordText = findViewById(R.id.password_text)

        val username = intent.getStringExtra("username")
        val password = intent.getStringExtra("password")

        usernameText.text = username
        passwordText.text = password
    }
}