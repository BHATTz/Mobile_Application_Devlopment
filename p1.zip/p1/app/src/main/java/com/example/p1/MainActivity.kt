package com.example.p1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var factorialText = findViewById<EditText>(R.id.factorialText)
        var factCalc = findViewById<Button>(R.id.factCalc)
        var armstrongText = findViewById<EditText>(R.id.armstrongText)
        var armCheck = findViewById<Button>(R.id.armCheck)
        var out = findViewById<TextView>(R.id.Output)
        var clear = findViewById<Button>(R.id.clear)

        factCalc.setOnClickListener {
            var number = factorialText.text.toString().toInt()
            var factorial = calculateFact(number)
            var square = squareFun(number)
            out.text = "Factorial of $number is: $factorial\nSquare of $number is: $square"
        }

        armCheck.setOnClickListener {
            var number = armstrongText.text.toString().toInt()
            var reverse = number.toString().reversed()
            var arm = checkArm(number)
            if(number == checkArm(number)){
                out.text= "Reverse of $number is: $reverse\n$number an armstrong number!"

            }else{
                out.text = "Reverse of $number is: $reverse\n$number Not an armstrong number!"
            }

        }
        clear.setOnClickListener {
            out.text = ""
        }

    }


    private fun calculateFact(number:Int):Int {
        var factorial = 1
        for (i in 10
                ..number) {
            factorial *= i
        }
        return factorial
    }

    private fun squareFun(number: Int):Int{
        var square = number
        square *= square
        return square
    }

    private fun checkArm(number:Int): Int{
        var temp = number
        var count = countDigit(number)
        var result:Int = 0
        var digit: Int

        while(temp>0){
            digit = temp%10
            result += Math.pow(digit.toDouble(), count.toDouble()).toInt()
            temp/=10
        }
        return result
    }

    private fun countDigit(number:Int): Int{
        var temp = number
        var count: Int = 0
        while(temp>0){
            count++
            temp/=10
        }
        return count
    }

}