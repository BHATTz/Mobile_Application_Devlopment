package com.example.rw_pc_23

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.rw_pc_23.databinding.ActivityMainBinding
import android.content.Intent
import android.net.Uri
import android.view.View

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private var nameList : MutableList<SampleModel> = mutableListOf()
    private lateinit var sampleAdapter: SampleAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        loadData()
        sampleAdapter = SampleAdapter(nameList)
        binding.apply {
            rvMain.apply {
                layoutManager=LinearLayoutManager(this@MainActivity)
                adapter=sampleAdapter
            }
        }

    }

    fun loadData(){
        nameList.add(SampleModel(1,"9898765438, xyz@gmail.com"))
        nameList.add(SampleModel(2,"3453212345, abc@gmail.com"))
        nameList.add(SampleModel(3,"9807658976, 123@gmail.com"))
    }

        fun call(view: View) {
            val dialIntent = Intent(Intent.ACTION_DIAL)
            dialIntent.data = Uri.parse("tel:" + "8344814819")
            startActivity(dialIntent)
    }
}