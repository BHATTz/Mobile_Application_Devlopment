package com.example.rw_pc_23

data class SampleModel(val id:Int , val name: String)
